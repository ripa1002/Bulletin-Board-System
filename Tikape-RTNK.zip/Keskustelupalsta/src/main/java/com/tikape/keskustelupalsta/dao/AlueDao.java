
package com.tikape.keskustelupalsta.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.tikape.keskustelupalsta.domain.Alue;


public class AlueDao implements Dao<Alue, String> {
    private Database database;
    
    public AlueDao(Database database) {
        this.database = database;
    }
    
    @Override
    public Alue create(Alue t) throws SQLException {
        Connection connection = this.database.getConnection();
        connection.createStatement().execute("INSERT INTO Alue (name) VALUES('" + t.getName() + "')");
        connection.close();

        return new Alue(t.getId(),t.getName());                    
    }

    @Override
    public Alue findOne(String key) throws SQLException {
        for (Alue alue : this.findAll()) {
            if (alue.getId() == Integer.parseInt(key)) {
                return alue;
            }
        }
        return null;    
    }

    @Override
    public List<Alue> findAll() throws SQLException {
        List<Alue> kaikkiLista = new ArrayList<>();
        Connection connection = this.database.getConnection();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Alue");
        ResultSet kaikki = stmt.executeQuery();
        
        while (kaikki.next()) {
            Alue a = new Alue(kaikki.getInt("id"),kaikki.getString("name"));
            kaikkiLista.add(a);
        }      
        kaikki.close();
        stmt.close();
        connection.close();
        
        return kaikkiLista;            
    }
}
