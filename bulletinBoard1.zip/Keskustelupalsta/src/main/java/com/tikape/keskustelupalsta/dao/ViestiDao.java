
package com.tikape.keskustelupalsta.dao;

import java.sql.*;
import com.tikape.keskustelupalsta.domain.Alue;
import com.tikape.keskustelupalsta.domain.Ketju;
import com.tikape.keskustelupalsta.domain.Viesti;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

// Data access object for message
public class ViestiDao implements Dao<Viesti, String> {
    private Database database;
    
    public ViestiDao(Database database) {
        this.database = database;
    }

    // Creates new message and add's it to database. Returns Viesti object.
    @Override
    public Viesti create(Viesti t) throws SQLException {
        Connection connection = this.database.getConnection();
        connection.createStatement().execute("INSERT INTO Viesti(alue_id, ketju_id, sisalto, nimimerkki, aika) VALUES('" + t.getAlue().getId() + "','" + t.getKetju().getId() + "','" + t.getSisalto() + "','" + t.getNimimerkki() + "','" + new SimpleDateFormat("dd-MM-yyyy HH:mm").format(Calendar.getInstance().getTime()) +"')");
        connection.close();
        return new Viesti(t.getKetju(),t.getSisalto(), t.getNimimerkki());
    }
    
    // Finds one message. Gets String-type key for parameter and returns Viesti object or null if it doesnt exist.
    @Override
    public Viesti findOne(String key) throws SQLException {
        for (Viesti viesti : this.findAll()) {
            if (viesti.getId() == Integer.parseInt(key)) {
                return viesti;
            }
        }
        return null;
    }

    // Finds all messages. Returns List of Viesti objects.
    @Override
    public List<Viesti> findAll() throws SQLException {
        List<Viesti> kaikkiViestit = new ArrayList();
        Connection connection = this.database.getConnection();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Viesti");
        ResultSet kaikki = stmt.executeQuery();
        KetjuDao ketjudao = new KetjuDao(database);
        AlueDao aluedao = new AlueDao(database);
        
        while (kaikki.next()) {
            Viesti a = new Viesti(kaikki.getInt("id"), aluedao.findOne(kaikki.getString("alue_id")), ketjudao.findOne(kaikki.getString("ketju_id")), kaikki.getString("sisalto"), kaikki.getString("nimimerkki"), kaikki.getString("aika"));
            kaikkiViestit.add(a);
        }
        
        kaikki.close();
        stmt.close();
        connection.close();
        
        return kaikkiViestit;
    }
    
    // Finds all messages from particular area. Returns List of Viesti objects.
    public List<Integer> findAllViestitAlueella() throws SQLException {
        List<Integer> alueenViestit = new ArrayList();
        AlueDao aluedao = new AlueDao(database);
        for (Alue alue : aluedao.findAll()) {
            List<Viesti> kaikkiViestitAlueella = new ArrayList();
            for (Viesti viesti : this.findAll()) {
                if (alue.getId().equals(viesti.getAlue().getId())) {
                    kaikkiViestitAlueella.add(viesti);
                }
            }
            alueenViestit.add(kaikkiViestitAlueella.size());
        }
        return alueenViestit;
    }
    
    // Finds all messages from particular chain. Get's String-type key for parameter(area) and returns List of Viesti objects.
    public List<Integer> findAllKetjunViestit(String alue) throws SQLException {
        List<Integer> ketjunViestit = new ArrayList();
        KetjuDao ketjudao = new KetjuDao(database);           
        for (Ketju ketju : ketjudao.findAll()) {
            List<Viesti> kaikkiViestitKetjussa = new ArrayList();
            for (Viesti viesti : this.findAll()) {
                if (ketju.getId().equals(viesti.getKetju().getId()) && alue.equals(viesti.getAlue().getId().toString())) {
                    kaikkiViestitKetjussa.add(viesti);
                }
            }
            if (!kaikkiViestitKetjussa.isEmpty()) {
                ketjunViestit.add(kaikkiViestitKetjussa.size()); 
            }       
        }
        return ketjunViestit;
    }
       
    // Finds correct timestamp for messages in areas.
    public HashMap<Integer,String> findAikaAlueittain() throws SQLException {               
        HashMap<Integer,String> viestienAjat = new HashMap();
        AlueDao aluedao = new AlueDao(database);
        for (Alue alue : aluedao.findAll()) {                      
            for (Viesti viesti : this.findAll()) {
                if (alue.getId().equals(viesti.getAlue().getId())) {
                    if (viestienAjat.size() < aluedao.findAll().size()) {
                        viestienAjat.put(alue.getId(), viesti.getAika());
                    }
                }                
            }
        }       
        return viestienAjat;
    }
    
    // Finds correct timestamp for messages in chains.
    public HashMap<Integer,String> findAikaKetjuittain(String alue) throws SQLException {               
        HashMap<Integer,String> viestienAjat = new HashMap();
        KetjuDao ketjudao = new KetjuDao(database);
        for (Ketju ketju : ketjudao.findAll()) {                      
            for (Viesti viesti : this.findAll()) {
                if (ketju.getId().equals(viesti.getKetju().getId()) && viesti.getAlue().getId().toString().equals(alue)) {
                    if (viestienAjat.size() <= ketjudao.findAllKetjutAlueelta(alue).size()) {
                        viestienAjat.put(ketju.getId(), viesti.getAika());
                    }
                }                
            }
        }       
        return viestienAjat;
    }
}
