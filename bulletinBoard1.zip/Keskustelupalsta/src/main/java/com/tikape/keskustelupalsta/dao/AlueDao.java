
package com.tikape.keskustelupalsta.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.tikape.keskustelupalsta.domain.Alue;

// Data access object for area
public class AlueDao implements Dao<Alue, String> {
    private Database database;
    
    public AlueDao(Database database) {
        this.database = database;
    }
    
    // Creates new area and add's it to database. Returns Alue object.
    @Override
    public Alue create(Alue t) throws SQLException {
        Connection connection = this.database.getConnection();
        connection.createStatement().execute("INSERT INTO Alue (name) VALUES('" + t.getName() + "')");
        connection.close();

        return new Alue(t.getId(),t.getName());                    
    }
    
    // Finds one area. Gets String-type key for parameter and returns Alue object or null if it doesn't exist.
    @Override
    public Alue findOne(String key) throws SQLException {
        for (Alue alue : this.findAll()) {
            if (alue.getId() == Integer.parseInt(key)) {
                return alue;
            }
        }
        return null;    
    }
    // finds all areas. Returns List of Alue objects.
    @Override
    public List<Alue> findAll() throws SQLException {
        List<Alue> kaikkiLista = new ArrayList<>();
        Connection connection = this.database.getConnection();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Alue");
        ResultSet kaikki = stmt.executeQuery();
        
        while (kaikki.next()) {
            Alue a = new Alue(kaikki.getInt("id"),kaikki.getString("name"));
            kaikkiLista.add(a);
        }      
        kaikki.close();
        stmt.close();
        connection.close();
        
        return kaikkiLista;            
    }
}
