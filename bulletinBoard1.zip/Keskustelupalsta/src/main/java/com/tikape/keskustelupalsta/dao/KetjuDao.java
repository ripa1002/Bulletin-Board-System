
package com.tikape.keskustelupalsta.dao;

import java.sql.*;
import com.tikape.keskustelupalsta.domain.Alue;
import java.util.ArrayList;
import java.util.List;
import com.tikape.keskustelupalsta.domain.Ketju;

import java.util.Objects;

// Data access object for chain
public class KetjuDao implements Dao<Ketju, String> {
    private Database database;
    
    public KetjuDao(Database database) {
        this.database = database;
    }
    
    // Creates new chain in particular area and add's it to database. Returns Ketju object.
    @Override
    public Ketju create(Ketju t) throws SQLException {
        Connection connection = this.database.getConnection();
        connection.createStatement().execute("INSERT INTO Ketju (alue_id, name) VALUES('" + t.getAlue().getId() + "','"+t.getName()+"')");
        connection.close();
        return new Ketju(t.getId(),t.getAlue(),t.getName());
    }

    // Finds one chain. Gets String-type key for parameter and returns Ketju object or null if it doesnt exist.
    @Override
    public Ketju findOne(String key) throws SQLException {
        for (Ketju ketju : this.findAll()) {
            if (ketju.getId() == Integer.parseInt(key)) {
                return ketju;
            }
        }
        return null;
    }
    
    // Finds one chain from particular area. Gets 2 String-type key's for parameters(first for area, second for chain) and returns Ketju object or null if it doesnt exist.
    public Ketju findOne(Alue alue, String nimi) throws SQLException {
        for (Ketju ketju : this.findAll()) {
            if (Objects.equals(ketju.getAlue().getId(), alue.getId())) {
                if (ketju.getName().equals(nimi)) {
                    return ketju;
                }
            }
        }
        return null;
    }
    
    // Finds all chains from particular are. Get's String-type key for parameter(area) and returns List of Ketju objects.    
    public List<Ketju> findAllKetjutAlueelta(String key) throws SQLException {
        List<Ketju> ketjulista = new ArrayList();
        for (Ketju ketju : this.findAll()) {
            if (Objects.equals(ketju.getAlue().getId().toString(), key)) {
                ketjulista.add(ketju);
            }
        }
        return ketjulista;
    }
    
    // Finds all chains. Returns List of Ketju objects.
    @Override
    public List<Ketju> findAll() throws SQLException {
        List<Ketju> kaikkiLista = new ArrayList();
        Connection connection = this.database.getConnection();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Ketju");
        ResultSet kaikki = stmt.executeQuery();
        AlueDao alueDao = new AlueDao(database);
        
        while (kaikki.next()) {                                             
            Ketju a = new Ketju(kaikki.getInt("id"), alueDao.findOne(kaikki.getString("alue_id")),kaikki.getString("name"));
            kaikkiLista.add(a);
        }
        kaikki.close();
        stmt.close();
        connection.close();
        
        return kaikkiLista;
    }   
}

